var Personnel = require('../models/personnel').Personnel;
var Affectation = require('../models/affectation').Affectation;
var audit = require('../utils/audit-log');
var log = require('../utils/log');
var mail = require('../utils/mail');
var fs = require('fs');
var Excel = require('exceljs');
var keyGenerator = require("generate-key");
var _ = require('lodash');
var crypto = require('crypto');
var dictionary = require('../utils/dictionary');
var formidable = require("formidable");
var mysql = require('mysql');
var phantomjs = require('phantomjs');
var pdf = require('dynamic-html-pdf');
var moment = require('moment');
var ObjectID = require('mongoose').mongo.ObjectID;

// API
exports.api = {};

var controllers = {
    affectations: require('./affectations'),
    configuration: require('./configuration'),
    users: require('./users'),
    positions: require('./positions'),
    structures: require('./structures'),
    thresholds: require('./thresholds')
};

exports.upsert = function (fields, callback) {
    // Parse received fields
    var id = fields._id || '';
    var matricule = fields.matricule || '';
    var identifier = fields.identifier || '';
    var mysqlId = fields.mysqlId || '';

    var filter = {$and: []};
    if (id !== '') {
        filter.$and.push({
            "_id": id
        });
    } else if (identifier !== '') {
        filter.$and.push({
            "identifier": identifier
        });
    } else if (matricule !== '') {
        filter.$and.push({
            "identifier": matricule
        });
    } else if (matricule !== '') {
        filter.$and.push({
            "mysqlId": mysqlId
        });
    } else {
        filter = fields;
    }
    fields.lastModified = new Date();
    Personnel.findOneAndUpdate(filter, fields, {setDefaultsOnInsert: true, upsert: true, new : true}, function (err, result) {
        if (err) {
            log.error(err);
            audit.logEvent('[mongodb]', 'Personnel', 'Upsert', "", "", 'failed', "Mongodb attempted to update a personnel");
            callback(err);
        } else {
            callback(null, result);
        }
    });
};


exports.api.upsert = function (req, res) {
    if (req.actor) {
        var form = new formidable.IncomingForm();
        form.parse(req, function (err, fields, files) {
            if (err) {
                log.error(err);
                audit.logEvent('[formidable]', 'Personnel', 'Upsert', "", "", 'failed', "Formidable attempted to parse personnel fields");
                return res.status(500).send(err);
            } else {
                exports.upsert(fields, function (err) {
                    if (err) {
                        log.error(err);
                        return res.status(500).send(err);
                    } else {
                        res.sendStatus(200);
                    }
                });
            }
        });
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'Upsert', '', '', 'failed', 'The actor was not authenticated');
        return res.sendStatus(401);
    }
};

exports.DONOTUSETHISMETHODE = function (callback) {//Insert a user from mysql database
    var con = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "",
        database: "sygepet"
    });

    con.connect(function (err) {
        if (err)
            throw err;
        con.query("SELECT * FROM personnel", function (err, personnels, fields) {
            if (err) {
                throw err;
            } else {
                var avoidedPersonnel = [];
                var eci = 1;
                function loopA(a) {
                    if (a < personnels.length) {
                        var personne = JSON.parse(JSON.stringify(personnels[a]));
                        var fieldPerso = {
                            "mysqlId": personne.id,
                            "identifier": personne.matricule.replace(/\s+/g, ''),
                            "name": {
                                "family": personne.nom,
                                "given": personne.prenom,
                                "maiden": personne.nomDeJeuneFille
                            },
                            "status": personne.idStatut,
                            "grade": personne.idGrade,
                            "category": personne.idCategorie,
                            "gender": personne.sexe,
                            "birthDate": new Date(personne.dateNaissance || null),
                            "birthPlace": personne.lieuNaissance,
                            "children": personne.nbreEnfant,
                            "maritalStatus": personne.situationFamiliale,
                            "father": "",
                            "mother": "",
                            "partner": "",
                            "telecom": [
                                {
                                    "system": "phone",
                                    "value": personne.telephone,
                                    "use": "home"
                                },
                                {
                                    "system": "email",
                                    "value": personne.email
                                }
                            ],
                            "address": [
                                {
                                    "country": 1,
                                    "region": personne.idRegion,
                                    "department": personne.idDepartement,
                                    "arrondissement": ""
                                }
                            ],
                            "cni": {
                                "identifier": personne.numCNI,
                                "date": new Date(personne.dateDelivCNI || null),
                                "city": personne.lieuDelivCNI,
                                "by": personne.cniDelivrePar
                            },
                            "created": new Date(personne.dateEnregistrement || null),
                            "lastModified": new Date(personne.miseajour || null)
                        };
                        if (personne.matricule == "ECI") {
                            fieldPerso.identifier = "ECI-" + eci;
                            eci = eci + 1;
                        }
                        exports.findByMatricule({matricule: fieldPerso.identifier}, function (err, personnel) {
                            if (err) {
                                log.error(err);
                                callback(err);
                            } else {
                                if (personnel != null) {// If this structure already exist
                                    if (!personnel.grade || personnel.grade == null || personnel.grade == "null" || !personnel.category || personnel.category == null || personnel.category == "null") {
                                        exports.upsert(fieldPerso, function (err, structure) {
                                            if (err) {
                                                log.error(err);
                                            } else {
                                                loopA(a + 1);
                                            }
                                        });
                                    } else {
                                        avoidedPersonnel.push(personnel.identifier);
                                        loopA(a + 1);
                                    }
                                } else {
                                    exports.upsert(fieldPerso, function (err, structure) {
                                        if (err) {
                                            log.error(err);
                                        } else {
                                            loopA(a + 1);
                                        }
                                    });
                                }
                            }
                        });

                    } else {
                        callback(null, avoidedPersonnel);
                    }
                }
                loopA(0);
            }
        });
    })
}

exports.api.list = function (req, res) {

    var minify = false;
    if (req.params.minify && req.params.minify == "true") {
        minify = true;
    }
    var limit = 0;
    var skip = 0;
    if (req.params.limit && req.params.skip) {
        limit = parseInt(req.params.limit, 10);
        skip = parseInt(req.params.skip, 10);
    }
    var filtersParam = {}
    if (req.params.filters && req.params.filters != "-" && req.params.filters != "") {
        filtersParam = JSON.parse(req.params.filters);
    }

    if (req.actor) {
        controllers.users.findUser(req.actor.id, function (err, user) {
            if (err) {
                log.error(err);
                callback(err);
            } else {
                var userStructure = [];
                var userStructureCodes = [];
                function LoopS(s) {
                    if (user.structures && s < user.structures.length && user.structures[s]) {
                        controllers.structures.find(user.structures[s], "en", function (err, structure) {
                            if (err) {
                                log.error(err);
                                callback(err);
                            } else {
                                userStructure.push({id: structure._id, code: structure.code});
                                userStructureCodes.push(new RegExp("^" + structure.code + "-"));
                                LoopS(s + 1);
                            }
                        });
                    } else {
                        var options = {
                            minify: minify,
                            req: req,
                            limit: limit,
                            skip: skip,
                            search: req.params.search,
                            filters: filtersParam
                        }

                        if (options.req.actor.role == "1" || options.req.actor.role == "3" || options.req.actor.role == "4" || options.req.actor.role == "2") {
                            var projection = {_id: 1, name: 1, "retirement": 1, matricule: 1, metainfo: 1, gender: 1, grade: 1, category: 1, index: 1, cni: 1, status: 1,
                                identifier: 1, corps: 1, telecom: 1, fname: 1, "affectation._id": 1, "affectation.positionCode": 1, "situations": 1,
                                "affectation.position.fr": 1,
                                "affectation.rank": 1,
                                "affectation.position.en": 1,
                                "affectation.position.code": 1,
                                "affectation.position.structureId": 1,
                            };
                            options.projection = projection;

                            if (options.minify == true) {
                                projection = {_id: 1, name: 1, matricule: 1, metainfo: 1, gender: 1, grade: 1, category: 1, cni: 1, status: 1,
                                    identifier: 1, corps: 1, telecom: 1, fname: 1
                                };
                            }
                            console.log("==== Liste affiche 1");
                            exports.list(options, function (err, personnels) {
                                if (err) {
                                    log.error(err);
                                    res.status(500).send(err);
                                } else {
                                    console.log("==== Liste affiche Apres ");
                                    personnels.sort(function (a, b) {
                                        if (a.fname < b.fname) {
                                            return -1;
                                        } else
                                        if (a.fname > b.fname) {
                                            return 1;
                                        } else
                                            return 0;
                                    })
                                    return res.json({data: personnels, count: 0});
                                }
                            });

                        } else {
                            var aggregat = [
                                {"$match": {
                                        "positionCode": {$in: userStructureCodes},
                                        "retirement.notified": {$exists: false}
                                    }
                                },
                                {$group: {_id: null, theCount: {$sum: 1}}},
                                {$project: {_id: 0}}
                            ];
                            q = Affectation.aggregate(aggregat);
                            q.exec(function (err, affectations) {
                                if (err) {
                                    log.error(err);
                                    callback(err);
                                } else {

                                    exports.list(options, function (err, personnels) {
                                        if (err) {
                                            log.error(err);
                                            res.status(500).send(err);
                                        } else {
                                            personnels.sort(function (a, b) {
                                                if (a.fname < b.fname) {
                                                    return -1;
                                                } else
                                                if (a.fname > b.fname) {
                                                    return 1;
                                                } else
                                                    return 0;
                                            })
                                            return res.json({data: personnels, count: affectations[0].theCount});
                                        }
                                    });
                                }
                            })
                        }

                    }
                }
                LoopS(0);
            }
        });
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'List', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

//Get all retired staff
exports.api.retired = function (req, res) {
    if (req.actor) {
        var limit = 0;
        var skip = 0;
        if (req.params.limit && req.params.skip) {
            limit = parseInt(req.params.limit, 10);
            skip = parseInt(req.params.skip, 10);
        }
        var filtersParam = {}
        if (req.params.filters && req.params.filters != "-" && req.params.filters != "") {
            filtersParam = JSON.parse(req.params.filters);
        }

        var from = filtersParam.from;
        var to = filtersParam.to;

        var query1 = {$and: []};
        if (filtersParam.retirementState === 4) {//Les personnes qui irrons probablement en retraite dans une date future
            query1.$and.push({$or: []});
            query1.$and[0].$or.push({"retirement.retirement": {$exists: false}});//pas en age de retraite
            query1.$and[0].$or.push({"retirement.retirement": false});//pas en age de retraite
        } else if (filtersParam.retirementState === 1) {//Retired and not notified staff (personne en age de retraite, mais pas notifiée)
            query1.$and.push({"retirement.retirement": true});//Les personnes en age de retraite
            query1.$and.push({"retirement.notified": {$exists: false}});//..et notifiés
            query1.$and.push({$or: []});//..et non pas été prolongés
            query1.$and[2].$or.push({"retirement.extended": {$exists: false}});//non pas été prolongés
            query1.$and[2].$or.push({"retirement.extended": false});//non pas été prolongés
        } else if (filtersParam.retirementState === 2) {//Retired and notified staff (personne retraitées, notifiées et pas prolongé)
            query1.$and.push({"retirement.retirement": true});//Les personnes en age de retraite
            query1.$and.push({"retirement.notified": {$exists: true}});//..et notifiés
            query1.$and.push({$or: []});//..et non pas été prolongés
            query1.$and[2].$or.push({"retirement.extended": {$exists: false}});//non pas été prolongés
            query1.$and[2].$or.push({"retirement.extended": false});//non pas été prolongés
        } else if (filtersParam.retirementState === 3) {//retired, but extended (prolongé)
            var query1 = {$and: []};
            query1.$and.push({"retirement.retirement": true});//Les personnes en age de retraite
            query1.$and.push({"retirement.extended": true});//retired, but extended
        }

        var options = {
            query: query1,
            req: req,
            retiredOnly: true,
            retirementState: filtersParam.retirementState,
            from: from,
            to: to
        }
        exports.list(options, function (err, personnels) {
            if (err) {
                log.error(err);
                res.status(500).send(err);
            } else {
                return res.json(personnels);
            }
        });
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'retired', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

//This function is called each day at 6am and check and set the new retired people
exports.checkRetirement = function (callback) {
//    Personnel.connection.db.createCollection('view_test', {
//        viewOn: 'personnels',
//        pipeline: [{"$match": {"retirement.retirement": true}}]
//    });

    var dateLimit = new Date(new Date().setFullYear(new Date().getFullYear() - 40));

    var query = {
        $and: [
            {
                "retirement.retirement": false
            },
            {
                "birthDate": {
                    $lte: moment(dateLimit).endOf('day')
                }
            }
        ]
    };
    controllers.thresholds.read('1', function (err, threshold1) {
        if (err) {
            log.error(err);
            callback(err);
        } else {
            controllers.thresholds.read('2', function (err, threshold2) {
                if (err) {
                    log.error(err);
                    callback(err);
                } else {
                    var q = Personnel.find(query);
                    q.exec(function (err, personnels) {
                        if (err) {
                            log.error(err);
                            audit.logEvent('[mongodb]', 'Personnel', 'checkRetirement', '', '', 'failed', 'Mongodb attempted to retrieve personnel list');
                            callback(err);
                        } else {
                            var candidates = [];
                            function LoopA(a) {
                                if (a < personnels.length && personnels[a]) {
                                    var age = _calculateAge(new Date(personnels[a].birthDate));
                                    //Decree N°2020/802 of 30 December 2020 of the President of the Republic harmonising the retirement age of civil servants.
                                    if (personnels[a].status == "1") {//Civil servant
                                        if (personnels[a].category && personnels[a].category != null && personnels[a].category != "") {
                                            if ((personnels[a].category == "5" || personnels[a].category == "6") && age >= parseInt(threshold1.values[1])) { //for category 'C' and 'D' staff, retirement at 55
                                                candidates.push(personnels[a]._id);
                                            } else if (age >= parseInt(threshold1.values[0])) {//Harmonised at sixty (60) years for category 'A' and 'B' staff

                                                candidates.push(personnels[a]._id);
                                            }
                                        } else if (age >= parseInt(threshold1.values[0])) {//Harmonised at sixty (60) years in case of other categories

                                            candidates.push(personnels[a]._id);
                                        }
                                    } else {// Contractual
                                        if (personnels[a].category && personnels[a].category != null && personnels[a].category != "") {
                                            if (parseInt(personnels[a].category, 10) >= 1 && parseInt(personnels[a].category, 10) <= 7 && age >= parseInt(threshold2.values[1])) { //Personnel non fonctionnaire CAT 1 à CAT 7 at 55 ans
                                                candidates.push(personnels[a]._id);
                                            } else if (age >= parseInt(threshold2.values[0])) {//Personnel non fonctionnaire CAT 8 à CAT 12 à 60 ans
                                                candidates.push(personnels[a]._id);
                                            }
                                        } else if (age >= parseInt(threshold2.values[0])) {//other in case
                                            candidates.push(personnels[a]._id);
                                        }
                                    }
                                    LoopA(a + 1);
                                } else {
                                    function LoopB(b) {
                                        if (b < candidates.length) {
                                            var situations = candidates[b].situations;
                                            var newSituation = {
                                                situation: "12", //Retirement
                                                numAct: "#", //Auto genereted by the bot
                                                nature: "#"//Auto genereted by the bot
                                            }
                                            if (situations) {
                                                situations.push(newSituation)
                                            } else {
                                                situations = [];
                                                situations.push(newSituation)
                                            }

                                            var fields = {
                                                "_id": candidates[b],
                                                "retirement.retirement": true,
                                                "retirement.retirementDate": new Date(),
                                                "situations": situations
                                            }
                                            exports.upsert(fields, function (err) {
                                                if (err) {
                                                    log.error(err);
                                                    callback(err);
                                                } else {
                                                    LoopB(b + 1);
                                                }
                                            });
                                        } else {
                                            if (candidates.length > 0) {
                                                audit.logEvent('[mongodb]', 'Personnel', 'checkRetirement', '', '', 'failed', "Admineex found " + candidates.length + ' new people of retirement age.');
                                            }
                                            callback(null, candidates.length);
                                        }
                                    }
                                    LoopB(0);
                                }
                            }
                            LoopA(0);
                        }
                    });
                }
            });
        }
    });
}


exports.list = function (options, callback) {
    controllers.users.findUser(options.req.actor.id, function (err, user) {
        if (err) {
            log.error(err);
            callback(err);
        } else {
            var userStructure = [];
            var userStructureCodes = [];
            console.log("==== Liste affiche - LoopS start");
            function LoopS(s) {
                if (user.structures && s < user.structures.length && user.structures[s]) {
                    controllers.structures.find(user.structures[s], "en", function (err, structure) {
                        if (err) {
                            log.error(err);
                            callback(err);
                        } else {
                            userStructure.push({id: structure._id, code: structure.code});
                            userStructureCodes.push(new RegExp("^" + structure.code + "-"));
                            LoopS(s + 1);
                        }
                    });
                } else {
                    console.log("==== Liste affiche - LoopS end");
                    if (options.req.actor.role == "1" || options.req.actor.role == "3" || options.req.actor.role == "4" || options.req.actor.role == "2") {
                        var query = {};
                        if (options.query) {
                            query = options.query;
                        }
                        var concat = [
                            {"$ifNull": ["$name.family", ""]},
                            " ",
                            {"$ifNull": ["$name.given", ""]}
                        ];
                        var concatMeta = [
                            {"$ifNull": ["$name.family", ""]},
                            {"$ifNull": ["$name.given", ""]},
                            {"$ifNull": ["$identifier", ""]}
                        ];


                        var sort = {"metainfo": 'asc'};
                        var q;
                        if (options.search && (options.search == "-" || options.search == "")) {
                            options.search = "";
                        }

                        var aggregate = [];
                        //Set the filters
                        if (options.filters) {
                            if (options.filters.gender && options.filters.gender != "-" && options.filters.gender != "") {
                                aggregate.push({$match: {gender: options.filters.gender}});
                            }

                            if (options.filters.status && options.filters.status != "-" && options.filters.status != "") {
                                aggregate.push({$match: {status: options.filters.status}});
                            }

                            if (options.filters.grade && options.filters.grade != "-" && options.filters.grade != "") {
                                aggregate.push({$match: {grade: options.filters.grade}});
                            }

                            if (options.filters.category && options.filters.category != "-" && options.filters.category != "") {
                                aggregate.push({$match: {category: options.filters.category}});
                            }

                            if (options.filters.situation && options.filters.situation != "-" && options.filters.situation != "") {
                                aggregate.push({$addFields: {lastSituation: {$arrayElemAt: ["$situations", -1]}}});

                                if (options.filters.situation == "12") {
                                    aggregate.push({"$match": {"retirement.retirement": true}});
                                    aggregate.push({"$match": {"retirement.notified": {$exists: false}}});
                                    aggregate.push({"$match": {$or: [{"retirement.extended": {$exists: false}}, {"retirement.extended": false}]}});
                                } else if (options.filters.situation == "0") {//Active people
                                    //Staff not (Deceased, Retired, Abandoned, Revoked)
                                    aggregate.push({$match: {$and: [{"lastSituation.situation": {$ne: "3"}}, {"lastSituation.situation": {$ne: "5"}}, {"lastSituation.situation": {$ne: "8"}}, {"lastSituation.situation": {$ne: "10"}}]}});
                                } else {
                                    aggregate.push({$match: {"lastSituation.situation": options.filters.situation}});
                                }
                            }
                        }

                        if (!options.statistics) {
                            aggregate.push({"$unwind": "$name"});
                            aggregate.push({"$unwind": {path: "$name.family", preserveNullAndEmptyArrays: true}});
                            aggregate.push({"$unwind": {path: "$name.given", preserveNullAndEmptyArrays: true}});
                            aggregate.push({"$unwind": {path: "$retirement", preserveNullAndEmptyArrays: true}});

                            aggregate.push({"$addFields": {"fname": {$concat: concat}}});
                            aggregate.push({"$addFields": {"matricule": "$identifier"}});
                            aggregate.push({"$addFields": {"metainfo": {$concat: concatMeta}}});
                            if (options.minify == false) {
                                aggregate.push(
                                        {
                                            $lookup: {
                                                from: 'affectations',
                                                localField: '_id',
                                                foreignField: 'personnelId',
                                                as: 'affectation',
                                            }
                                        }
                                );
                                aggregate.push(
                                        {"$addFields": {
                                                "affectation": {"$slice": ["$affectation", -1]}
                                            }
                                        }
                                );

                                aggregate.push(
                                        {
                                            "$unwind": {
                                                path: "$affectation",
                                                preserveNullAndEmptyArrays: true
                                            }
                                        }
                                );

                                if (options.req.actor.role == "2") {
                                    aggregate.push(
                                            {"$match": {"affectation.positionCode": {$in: userStructureCodes}}},
                                            );
                                }

                                aggregate.push(
                                        {
                                            $lookup: {
                                                from: 'positions',
                                                localField: 'affectation.positionCode',
                                                foreignField: 'code',
                                                as: 'affectation.position',
                                            }
                                        }
                                );

                                if (options.filters) {
                                    if (options.filters.structure && options.filters.structure != "-" && options.filters.structure != "") {
                                        aggregate.push({$match: {$or: [{"affectation.positionCode": new RegExp("^" + options.filters.structure)}]}})
                                    }
                                }

                                aggregate.push(
                                        {
                                            "$unwind": {
                                                path: "$affectation.position",
                                                preserveNullAndEmptyArrays: true
                                            }
                                        }
                                );
                            }

                        }
                        if (options.projection) {

                            options.projection.lastSituation = 1;
                            projection = {
                                $project: options.projection
                            };
                            aggregate.push(projection);
                        }
                        //Filter by key word
                        if (options.search) {
                            aggregate.push({$match: {$or: [{"metainfo": dictionary.makePattern(options.search)}]}});
                        }

                        //Filter by key word
                        if (options._id) {
                            aggregate.push({$match: {_id: new ObjectID(options._id)}});
                        }

                        //If retiredOnly
                        if (options.retiredOnly) {
                            aggregate.push({"$match": options.query});
                        } else {
                            aggregate.push({"$match": {"retirement.notified": {$exists: false}}});
                        }

                        if ((options.skip + options.limit) > 0) {
                            aggregate.push({"$limit": options.skip + options.limit})
                            aggregate.push({"$skip": options.skip})
                        }

                        q = Personnel.aggregate(aggregate);
                        console.log("==== Liste affiche - Before aggregation");
                        q.exec(function (err, personnels) {
                            if (err) {
                                log.error(err);
                                audit.logEvent('[mongodb]', 'Personnel', 'List', '', '', 'failed', 'Mongodb attempted to retrieve personnel list');
                                callback(err);
                            } else {
                                console.log("==== Liste affiche - After aggregation");
                                personnels = JSON.parse(JSON.stringify(personnels));
                                var retirementLimit;
                                console.log("==== Liste affiche - Loop  personnels");
                                function LoopA(a) {
                                    if (a < personnels.length && personnels[a]) {
                                        personnels[a].age = _calculateAge(new Date(personnels[a].birthDate));

                                        //Decree N°2020/802 of 30 December 2020 of the President of the Republic harmonising the retirement age of civil servants.
                                        if (personnels[a].status == "1") {//Civil servant
                                            if (personnels[a].category && personnels[a].category != null && personnels[a].category != "") {
                                                if ((personnels[a].category == "5" || personnels[a].category == "6")) { //for category 'C' and 'D' staff, retirement at 55
                                                    retirementLimit = 55;
                                                } else {//Harmonised at sixty (60) years for category 'A' and 'B' staff
                                                    retirementLimit = 60;
                                                }
                                            } else {//Harmonised at sixty (60) years in case of other categories
                                                retirementLimit = 60;
                                            }
                                        } else {// Contractual
                                            if (personnels[a].category && personnels[a].category != null && personnels[a].category != "") {
                                                if (parseInt(personnels[a].category, 10) >= 1 && parseInt(personnels[a].category, 10) <= 7) { //Personnel non fonctionnaire CAT 1 à CAT 7 at 55 ans
                                                    retirementLimit = 55;
                                                } else {//Personnel non fonctionnaire CAT 8 à CAT 12 à 60 ans
                                                    retirementLimit = 60;
                                                }
                                            } else {//other in case
                                                retirementLimit = 60;
                                            }
                                        }
                                        personnels[a].retirementDate = new Date(new Date(personnels[a].birthDate).setFullYear(new Date(personnels[a].birthDate).getFullYear() + retirementLimit));

                                        if ((options.minify == true || personnels[a].affectation) && !options.retiredOnly) {
                                            var options2 = {
                                                req: options.req
                                            };
                                            options2.beautifyPosition = true;
                                            if (options.beautifyPosition == false) {
                                                options2.beautifyPosition = false;
                                            }

                                            if (options.toExport == true) {
                                                options2.toExport = true;
                                                //Address
                                                personnels[a].address = controllers.configuration.beautifyAddress({language: language}, [{address: personnels[a].address}])[0].address;
                                            }

                                            var status = (personnels[a].status) ? personnels[a].status : "";
                                            var grade = (personnels[a].grade) ? personnels[a].grade : "";
                                            var actif = (personnels[a].retirement && personnels[a].retirement.retirement == false) ? "Actif" : "En age de retraite";
                                            var situation = undefined;
                                            if (personnels[a].lastSituation && personnels[a].lastSituation.situation) {
                                                situation = dictionary.getValueFromJSON('../../resources/dictionary/personnel/situations.json', personnels[a].lastSituation.situation, language);
                                            }

                                            var language = options.language || "";
                                            language = language.toLowerCase();
                                            var statuse = (personnels[a].status) ? personnels[a].status : "";
                                            var grade = (personnels[a].grade) ? personnels[a].grade : "";
                                            var category = (personnels[a].category) ? personnels[a].category : "";

                                            personnels[a].active = (situation) ? situation : actif;
                                            personnels[a].status = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status.json', status, language);
                                            if (status != "") {
                                                if (status === "Fonctionnaire") status = "1";
                                                if (status === "Non-staff personnel" || status === "Personnel non fonctionnaires") status = "2";
                                                personnels[a].grade = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status/' + status + '/grades.json', parseInt(grade, 10), language);
                                                personnels[a].category = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status/' + status + '/categories.json', category, "code").toUpperCase();
                                            }

                                            if (personnels[a].affectation && personnels[a].affectation.position) {
                                                var personalRank = (personnels[a].affectation.rank) ? personnels[a].affectation.rank : "";
                                                if (personalRank != ""){
                                                    personnels[a].affectation.rank = dictionary.getValueFromJSON('../../resources/dictionary/personnel/ranks.json', personalRank, language);
                                                }
                                                
                                                personnels[a].affectation.position.name = ((language && language !== "" && personnels[a].affectation.position[language] != undefined && personnels[a].affectation.position[language] != "") ? personnels[a].affectation.position[language] : personnels[a].affectation.position['en']);
                                                controllers.structures.findStructureByCode(personnels[a].affectation.position.code.substring(0, personnels[a].affectation.position.code.indexOf('P')), language, function (err, structure) {
                                                    if (err) {
                                                        log.error(err);
                                                        callback(err);
                                                    } else {
                                                        personnels[a].affectation.structure = structure;
                                                        LoopA(a + 1);
                                                    }
                                                });
                                            } else {
                                                LoopA(a + 1);
                                            }
                                        } else if (options.retiredOnly) {
                                            var status = (personnels[a].status) ? personnels[a].status : "";
                                            var grade = (personnels[a].grade) ? personnels[a].grade : "";
                                            var language = options.language || "";
                                            language = language.toLowerCase();
                                            personnels[a].grade = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status/' + status + '/grades.json', parseInt(grade, 10), language);
                                            personnels[a].age = _calculateAge(new Date(personnels[a].birthDate));
                                            LoopA(a + 1);
                                        } else {
                                            LoopA(a + 1);
                                        }
                                    } else {
                                        callback(null, personnels);
                                    }
                                }
                                LoopA(0);
                            }
                        });
                    } else {//This view is restricted for structure manager (Role = 2)
                        var q;
                        var query = {positionCode: {$in: userStructureCodes}};
                        var concat = [{"$ifNull": ["$AffectedPersonnal.name.family", ""]}, " ", {"$ifNull": ["$AffectedPersonnal.name.given", ""]}];
                        var concatMeta = [
                            {"$ifNull": ["$AffectedPersonnal.name.family", ""]},
                            {"$ifNull": ["$AffectedPersonnal.name.given", ""]},
                            {"$ifNull": ["$AffectedPersonnal.identifier", ""]},
                            {"$ifNull": ["$positionCode", ""]}
                        ];
                        var sort = {"name.family": 'asc'};
                        var aggregat = [
                            {"$match": {"positionCode": {$in: userStructureCodes}}},
                            {
                                "$lookup": {
                                    "from": "personnels",
                                    "localField": "personnelId",
                                    "foreignField": "_id",
                                    "as": "AffectedPersonnal"
                                }
                            },
                            {"$unwind": "$AffectedPersonnal"},
                            {"$unwind": "$AffectedPersonnal.name"},
                            {"$unwind": {path: "$AffectedPersonnal.name.family", preserveNullAndEmptyArrays: true}},
                            {"$unwind": {path: "$AffectedPersonnal.name.given", preserveNullAndEmptyArrays: true}},
                            {"$addFields": {"fname": {$concat: concat}}},
                            {"$addFields": {"matricule": "$identifier"}},
                            {"$addFields": {"metainfo": {$concat: concatMeta}}}
                        ]

                        //Filter by key word
                        if (options.search && options.search != "-" && options.search != "") {
                            aggregat.push({$match: {$or: [{"metainfo": dictionary.makePattern(options.search)}]}})
                        }
                        //If retiredOnly
                        if (options.retiredOnly) {
                            aggregat.push({"$addFields": {"retirement": "$AffectedPersonnal.retirement.retirement"}});
                            aggregat.push({"$addFields": {"notified": "$AffectedPersonnal.retirement.notified"}});
                            aggregat.push({"$addFields": {"extended": "$AffectedPersonnal.retirement.extended"}});
                            aggregat.push({"$addFields": {"positionCode": "$positionCode"}});
                            aggregat.push({"$match": {"retirement": true}});
                            aggregat.push({"$match": {"notified": {$exists: true}}});
                            aggregat.push({"$match": {$or: [{"extended": {$exists: false}}, {"extended": false}]}});
                        }
                        //If Limit per page
                        if (options.skip && options.limit) {
                            aggregat.push({"$limit": options.skip + options.limit})
                            aggregat.push({"$skip": options.skip})
                        }
                        //Start
                        q = Affectation.aggregate(aggregat);
                        q.exec(function (err, affectations) {
                            if (err) {
                                log.error(err);
                                callback(err);
                            } else {
                                var personnelsManaged = [];
                                var personne;

                                function LoopAf(a) {
                                    if (affectations && a < affectations.length) {
                                        personne = affectations[a].AffectedPersonnal;
                                        personne.fname = affectations[a].fname;
                                        personne.metainfo = affectations[a].metainfo;
                                        controllers.positions.findPositionByCodeAndBeautify(affectations[a].positionCode, options, function (err, position) {
                                            if (err) {
                                                log.error(err);
                                                callback(err);
                                            } else {
                                                personne.affectedTo = {
                                                    position: position
                                                };
                                                personnelsManaged.push(personne);
                                                LoopAf(a + 1);
                                            }
                                        });
                                    } else {
                                        callback(null, personnelsManaged);
                                    }
                                }
                                LoopAf(0);
                            }
                        });
                    }
                }
            }
            LoopS(0);
        }
    });
}




exports.api.export = function (req, res) {
    console.log("==== Demarrage... ")
    if (req.actor) {
        if (req.params.filters == undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'Export', '', '', 'failed',
                    'The actor could not export the personnel list because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            var filtersParam = {}
            if (req.params.filters && req.params.filters != "-" && req.params.filters != "") {
                filtersParam = JSON.parse(req.params.filters);
            }

            var filter = {rank: "2"};
            if (filtersParam.structure != "-1" && filtersParam.structure != "undefined" && filtersParam.structure) {
                filter.code = filtersParam.structure;
                if (filter.code.endsWith("-")) {
                    filter.code = filtersParam.structure.slice(0, -1);
                }
            }
            var option = {
                actor: req.actor, language: req.actor.language, beautify: true, filter: filter
            }
            console.log("==== GET STRUCTURE ")
            controllers.structures.list(option, function (err, structures) {
                if (err) {
                    log.error(err);
                    res.status(500).send(err);
                } else {
                    console.log("==== GET STRUCTURE ", structures.length)
                    var options = {
                        minify: false,
                        req: req,
                        filters: filtersParam,
                        language: req.actor.language,
                        beautifyPosition: false,
                        toExport: true
                    }

                    var projection = {_id: 1, name: 1, "retirement": 1, matricule: 1, metainfo: 1, gender: 1, grade: 1, category: 1, index:1, cni: 1, status: 1,
                        identifier: 1, corps: 1, telecom: 1, fname: 1, "affectation._id": 1, "affectation.positionCode": 1, "situations": 1,
                        "affectation.position.fr": 1,
                        "affectation.position.en": 1,
                        "affectation.position.code": 1,
                        "affectation.position.structureId": 1,
                        "affectation.numAct": 1,
                        "affectation.rank": 1,
                        address: 1,
                        birthPlace: 1,
                        birthDate: 1,
                        "history.recruitmentActNumber": 1,
                        "history.signatureDate": 1,
                        "history.minfiEntryRefAct": 1
                    };

                    options.projection = projection;
                    console.log("==== Avant Export list")
                    exports.list(options, function (err, personnels) {
                        if (err) {
                            log.error(err);
                            res.status(500).send(err);
                        } else {
                            console.log("==== Apres Export list", personnels.length);
                            personnels.sort(function (a, b) {
                                if (a.fname < b.fname) {
                                    return -1;
                                } else
                                if (a.fname > b.fname) {
                                    return 1;
                                } else
                                    return 0;
                            })
                            var groupedPersonnelByStructureChildren = [];
                            if (filtersParam.staffOnly === false || filtersParam.staffOnly === "false") {
                                groupedPersonnelByStructureChildren["undefined"] = personnels;
                            } else {
                                groupedPersonnelByStructureChildren = _.groupBy(personnels, function (item) {
                                    if (item.affectation && item.affectation.structure && item.affectation.structure._id) {

                                        return item.affectation.structure._id;
                                    } else {
                                        return "undefined";
                                    }

                                });

                                for (var s in structures) {
                                    if (structures[s].children) {
                                        for (var c in structures[s].children) {
                                            structures[s].children[c].personnels = groupedPersonnelByStructureChildren[structures[s].children[c]._id]
                                        }
                                    }
                                }
                            }

                            if (groupedPersonnelByStructureChildren["undefined"]) {
                                var undefinedStructure = {
                                    code: "000",
                                    name: "STRUCTURE INCONNUE",
                                    children: [{
                                            code: "000 - 0",
                                            fr: "Inconue",
                                            personnels: groupedPersonnelByStructureChildren["undefined"]
                                        }]
                                }
                                structures.push(undefinedStructure);
                            }

                            var gt = dictionary.translator(req.actor.language);
                            //Build XLSX
                            var options = buildFields(req.actor.language, "fieldNames.json");
                            options.staffOnly = filtersParam.staffOnly;
                            options.data = structures;
                            options.title = gt.gettext("Admineex: Liste du personnel");
                            buildXLSX(options, function (err, filePath) {
                                if (err) {
                                    console.error(err);
                                    log.error(err);
                                } else {
                                    var fileName = 'report.xlsx';
                                    res.set('Content-disposition', 'attachment; filename=' + fileName);
                                    res.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                                    var fileStream = fs.createReadStream(filePath);
                                    var pipeStream = fileStream.pipe(res);
                                    pipeStream.on('finish', function () {
                                        fs.unlinkSync(filePath);
                                    });
                                }
                            });
                        }
                    });
                }
            });


        }
    }
}

function buildFields(language, file) {
    var fields = require("../../resources/dictionary/export/" + file);
    var options = {fields: [], fieldNames: []};
    for (i = 0; i < fields.length; i++) {
        options.fieldNames.push(((language != "" && fields[i][language] != undefined && fields[i][language] != "") ? fields[i][language] : fields[i]['en']));
        options.fields.push(fields[i].id);
    }
    return options;
}

exports.api.search = function (req, res) {
    if (req.actor) {
        if (req.params.text == undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'Search', '', '', 'failed',
                    'The actor could not read the personnel timeline because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            controllers.users.findUser(req.actor.id, function (err, user) {
                if (err) {
                    log.error(err);
                    callback(err);
                } else {
                    var userStructure = [];
                    var userStructureCodes = [];
                    function LoopS(s) {
                        if (user.structures && s < user.structures.length && user.structures[s]) {
                            controllers.structures.find(user.structures[s], "en", function (err, structure) {
                                if (err) {
                                    log.error(err);
                                    callback(err);
                                } else {
                                    userStructure.push({id: structure._id, code: structure.code});
                                    userStructureCodes.push(new RegExp("^" + structure.code + "-"));
                                    LoopS(s + 1);
                                }
                            });
                        } else {

                            var name = req.params.text || '';
                            var concat;

                            var concat = [
                                {"$ifNull": ["$name.family", ""]},
                                " ",
                                {"$ifNull": ["$name.given", ""]}
                            ];
                            var concatMeta = [
                                {"$ifNull": ["$name.family", ""]},
                                {"$ifNull": ["$name.given", ""]},
                                {"$ifNull": ["$identifier", ""]}
                            ];

                            if (name !== '') {
                                var aggregate = [
                                    {"$unwind": "$name"},
                                    {"$unwind": {path: "$name.family", preserveNullAndEmptyArrays: true}},
                                    {"$unwind": {path: "$name.given", preserveNullAndEmptyArrays: true}},
                                    {"$addFields": {"fname": {$concat: concat}}},
                                    {"$addFields": {"matricule": "$identifier"}},
                                    {"$addFields": {"metainfo": {$concat: concatMeta}}},
                                    {$addFields: {lastSituation: {$arrayElemAt: ["$situations", -1]}}},
                                    {$match: {$or: [{"metainfo": dictionary.makePattern(name)}]}}
                                ];

                                if (req.actor.role == "2") {
                                    aggregate.push(
                                            {
                                                $lookup: {
                                                    from: 'affectations',
                                                    localField: '_id',
                                                    foreignField: 'personnelId',
                                                    as: 'affectation',
                                                }
                                            }
                                    );
                                    aggregate.push(
                                            {
                                                "$unwind": {
                                                    path: "$affectation",
                                                    preserveNullAndEmptyArrays: false
                                                }
                                            }
                                    );


                                    aggregate.push(
                                            {"$match": {"affectation.positionCode": {$in: userStructureCodes}}},
                                            );
                                }


                                Personnel.aggregate(aggregate).exec(function (err, personnels) {
                                    if (err) {
                                        log.error(err);
                                        audit.logEvent('[mongodb]', 'Personnel', 'Search', '', '', 'failed', 'Mongodb attempted to retrieve a personnel');
                                        return res.sendStatus(500);
                                    } else {
                                        personnels = JSON.parse(JSON.stringify(personnels));
                                        beautify({req: req, language: req.actor.language, beautify: true}, personnels, function (err, objects) {
                                            if (err) {
                                                return res.status(500).send(err);
                                            } else {
                                                return res.json(objects);
                                            }
                                        });
                                    }
                                });

                            } else {
                                return res.json();
                            }
                        }
                    }
                    LoopS(0)
                }
            });
        }
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'Search', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

exports.api.checkExistance = function (req, res) {
    if (req.actor) {
        if (req.params.mat == undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'checkExistance', '', '', 'failed',
                    'The actor could not read the personnel timeline because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {

            var mat = req.params.mat || '';
            var concat;

            concat = ["$name.family", " ", "$name.given"];

            if (mat !== '') {
                Personnel.count({"identifier": mat}).exec(function (err, count) {
                    if (err) {
                        log.error(err);
                        audit.logEvent('[mongodb]', 'Personnel', 'checkExistance', '', '', 'failed', 'Mongodb attempted to checkExistance of identifier');
                        return res.sendStatus(500);
                    } else {
                        return res.json(count);
                    }
                });
            } else {
                return res.json(0);
            }
        }
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'Search', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

/**
 * This function output the list of staff corresponds to geven position
 * @param {type} req
 * @param {type} res
 * @returns {unresolved}
 */
exports.api.eligibleTo = function (req, res) {
    if (req.actor) {
        if (req.params.id == undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'EligibleTo', '', '', 'failed',
                    'The actor could not read the personnel eligible because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            var options = {
                position: {
                    id: req.params.id
                },
                req: req
            }

            exports.eligibleTo(options, function (err, objects) {
                if (err) {
                    log.error(err);
                    return res.sendStatus(400);
                } else {
                    return res.json(objects);
                }
            });
        }
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'Search', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

/**
 * This function download the list of staff corresponds to geven position
 * @param {type} req
 * @param {type} res
 * @returns {unresolved}
 */
exports.api.downloadEligibleTo = function (req, res) {
    if (req.actor) {
        if (req.params.id == undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'EligibleTo', '', '', 'failed',
                    'The actor could not read the personnel eligible because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            var options = {
                position: {
                    id: req.params.id
                },
                req: req
            }

            exports.eligibleTo(options, function (err, objects) {
                if (err) {
                    log.error(err);
                    return res.sendStatus(400);
                } else {
                    var gt = dictionary.translator(req.actor.language);
                    //Build XLSX
                    var options = buildFields(req.actor.language, "fieldNamesEligible.json");
                    options.data = objects;
                    options.title = gt.gettext("Admineex: Liste des personnes éligibles au poste de: ");
                    buildXLSX2(options, function (err, filePath) {
                        if (err) {
                            log.error(err);
                        } else {
                            var fileName = 'report.xlsx';
                            res.set('Content-disposition', 'attachment; filename=' + fileName);
                            res.set('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                            var fileStream = fs.createReadStream(filePath);
                            var pipeStream = fileStream.pipe(res);
                            pipeStream.on('finish', function () {
                                fs.unlinkSync(filePath);
                            });
                        }
                    });
                }
            });
        }
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'Search', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}


exports.eligibleTo = function (options, callback) {
    controllers.positions.find({_id: options.position.id}, function (err, position) {
        if (err) {
            log.error(err);
            callback(err);
        } else {
            var requiredProfiles = position.requiredProfiles;
            var requiredSkills = position.requiredSkills;

            if ((requiredProfiles && requiredProfiles.length > 0) || (requiredSkills && requiredSkills.length > 0)) {
                var concat;

                concat = ["$name.family", " ", "$name.given"];

                var query = {$or: []};
                var sort = {"name.family": 'asc'};
                query.$or.push({"profiles": {"$in": requiredProfiles}});
                query.$or.push({"skills": {"$in": requiredSkills}});
                var projection = {
                    _id: 1,
                    name: 1,
                    profiles: 1,
                    skills: 1,
                    identifier: 1,
                    grade: 1,
                    corps: 1,
                    status: 1
                };
                var q = Personnel.find(query, projection).sort(sort).limit(0).skip(0).lean();
                q.exec(function (err, personnels) {
                    if (err) {
                        log.error(err);
                        audit.logEvent('[mongodb]', 'Personnel', 'EligibleTo', '', '', 'failed', 'Mongodb attempted to retrieve a personnel');
                        callback(err);
                    } else {
                        personnels = JSON.parse(JSON.stringify(personnels));
                        beautify({req: options.req, language: options.req.actor.language, beautify: true, eligibleTo: position._id, position: position, eligible: true}, personnels, function (err, objects) {
                            if (err) {
                                callback(err);
                            } else {
                                callback(null, objects);
                            }
                        });
                    }
                });
            } else {
                callback(null, []);
            }
        }
    });

}





exports.api.read = function (req, res) {
    if (req.actor) {
        if (req.params.id === undefined) {
            audit.logEvent(req.actor.id, 'Position', 'Read', '', '', 'failed',
                    'The actor could not read the position because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            var filter = {
                _id: req.params.id
            };
            var isBeautify = false;
            if (req.params.beautify && req.params.beautify == "true") {
                isBeautify = true;
            }

            exports.read(filter, function (err, personnel) {
                if (err) {
                    return res.status(500).send(err);
                } else {
                    beautify({req: req, language: req.actor.language, beautify: isBeautify}, [personnel], function (err, objects) {
                        if (err) {
                            return res.status(500).send(err);
                        } else {
                            return res.json(objects[0]);
                        }
                    });
                }
            });
        }
    } else {
        audit.logEvent('[anonymous]', 'Projects', 'Read', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

exports.api.followUpSheet = function (req, res) {
    if (req.actor) {
        if (req.params.id === undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'Read', '', '', 'failed',
                    'The actor could not read the data information because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            var filter = {
                _id: req.params.id
            };
            var gt = dictionary.translator(req.actor.language);
            var foot = 'Admineex<br/>Imprimé le ' + dictionary.dateformater(new Date(), "dd/MM/yyyy HH:mm:s");

            var options = {
                phantomPath: phantomjs.path,
                format: "A4",
                orientation: "portrait",
                border: "5mm",
                "border-bottom": "5mm",
                pagination: true,
                paginationOffset: 1, // Override the initial pagination number
                "footer": {
                    "height": "10mm",
                    "contents": {
                        default: '<div style="width:100%"><div style="float:left;width:80%;font-size: 8px">' + foot + '</div><div style="float:left;width:20%;text-align:right;font-size: 8px">{{page}}/{{pages}}</div></div>', // fallback value
                    }
                }
            };

            var meta = {
                title: gt.gettext("Fiche de suivi du personnel")
            };

            var tmpFile = "./tmp/" + keyGenerator.generateKey() + ".pdf";
            if (!fs.existsSync("./tmp")) {
                fs.mkdirSync("./tmp");
            }

            var projection = {_id: 1, name: 1, "retirement": 1, matricule: 1, metainfo: 1, gender: 1, grade: 1, category: 1, index:1, cni: 1, status: 1,
                identifier: 1, corps: 1, telecom: 1, fname: 1, "affectation._id": 1, "affectation.positionCode": 1, "situations": 1,
                "affectation.position.fr": 1,
                "affectation.position.en": 1,
                "affectation.position.code": 1,
                "affectation.position.structureId": 1,
                "affectation.numAct": 1,
                "affectation.endDate": 1,
                address: 1,
                birthPlace: 1,
                birthDate: 1,
                "history.recruitmentActNumber": 1,
                "history.signatureDate": 1,
                "history.minfiEntryRefAct": 1
            };
            filter.projection = projection;
            var options1 = {
                minify: false,
                req: req,
                _id: req.params.id,
                language: req.actor.language,
                beautify: true,
            }

            exports.list(options1, function (err, personnels) {
                if (err) {
                    return res.status(500).send(err);
                } else {
                    personnels = controllers.configuration.beautifyAddress({language: req.language}, personnels);
                    personnels[0].address = personnels[0].address[0];
                    personnels[0].phone = personnels[0].telecom[0];
                    personnels[0].higherDiploma = personnels[0].qualifications.schools[0] ? personnels[0].qualifications.schools[0] : "";
                    personnels[0].recrutementDiploma = personnels[0].qualifications.schools[1] ? personnels[0].qualifications.schools[1] : "";
                    personnels[0].birthDate = personnels[0].birthDate ? moment(personnels[0].birthDate).format("DD/MM/YYYY") : "Non connue";
                    personnels[0].higherDiploma.date = personnels[0].higherDiploma ? moment(personnels[0].higherDiploma.date).format("DD/MM/YYYY") : "Non connue";
                    personnels[0].recrutementDiploma.date = personnels[0].recrutementDiploma ? moment(personnels[0].recrutementDiploma.date).format("DD/MM/YYYY") : "Non connue";
                    if (personnels[0].history) {
                        personnels[0].history.signatureDate = personnels[0].history ? moment(personnels[0].history.signatureDate).format("DD/MM/YYYY") : "Non connue";
                        personnels[0].history.minfiEntryDate = personnels[0].history ? moment(personnels[0].history.minfiEntryDate).format("DD/MM/YYYY") : "Non connue";
                    }
                    var options2 = {
                        req: req,
                        search: personnels[0].matricule,
                    }
                    controllers.affectations.list(options2, function (err, affectations) {
                        if (err) {
                            return res.status(500).send(err);
                        } else {
                            var document = {
                                type: 'file', // 'file' or 'buffer'
                                template: fs.readFileSync('resources/pdf/fiche_de_suivi.html', 'utf8'),
                                context: {
                                    personnel: personnels[0],
                                    meta: meta,
                                    affectations: affectations
                                },
                                path: tmpFile    // it is not required if type is buffer
                            };


                            pdf.create(document, options, res).then(res1 => {

                                var fileName = 'report.pdf';
                                res.set('Content-disposition', 'attachment; filename=' + fileName);
                                res.set('Content-Type', 'application/pdf');
                                res.download(tmpFile, fileName, function (err) {
                                    if (err) {
                                        log.error(err);
                                        return res.status(500).send(err);
                                    } else {
                                        fs.unlink(tmpFile, function (err) {
                                            if (err) {
                                                log.error(err);
                                                audit.logEvent('[fs]', 'Reports', 'Download', "Spreadsheet", tmpFile, 'failed', 'FS attempted to delete this temp file');
                                            }
                                        });
                                    }
                                });
                            }).catch(error => {
                                console.error(error)
                            });
                        }
                    });
                }
            });
        }
    } else {
        audit.logEvent('[anonymous]', 'Projects', 'Read', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

exports.read = function (options, callback) {
    Personnel.findOne({
        _id: options._id
    }).lean().exec(function (err, result) {
        if (err) {
            log.error(err);
            callback(err);
        } else {
            if (result) {
                callback(null, result);
            } else {
                callback(null);
            }
        }
    });
}

exports.findByMatricule = function (options, callback) {
    Personnel.findOne({
        identifier: options.matricule
    }).lean().exec(function (err, result) {
        if (err) {
            log.error(err);
            callback(err);
        } else {
            if (result) {
                callback(null, result);
            } else {
                callback(null);
            }
        }
    });
}

exports.api.delete = function (req, res) {
    if (req.actor) {
        if (req.params.id == undefined) {
            audit.logEvent(req.actor.id, 'Personnel', 'Remove', '', '', 'failed', 'The actor could not remove a personnel because one or more params of the request was not defined');
            return res.sendStatus(400);
        } else {
            Personnel.remove({_id: req.params.id}, function (err) {
                if (err) {
                    log.error(err);
                    return res.status(500).send(err);
                } else {
                    Affectation.remove({personnelId: req.params.id}, function (err) {
                        if (err) {
                            log.error(err);
                            return res.status(500).send(err);
                        } else {
                            audit.logEvent(req.actor.id, 'Personnel', 'Staff member deletion', "PersonnelID", req.params.id, 'succeed',
                                    'The actor has successfully deleted the staff member.');
                            return res.sendStatus(200);
                        }
                    });
                }
            });
        }
    } else {
        audit.logEvent('[anonymous]', 'Personnel', 'Staff member deletion', '', '', 'failed', 'The actor was not authenticated');
        return res.send(401);
    }
}

function _calculateAge(birthday) { // birthday is a date
    var ageDifMs = Date.now() - birthday.getTime();
    var ageDate = new Date(ageDifMs); // miliseconds from epoch
    return Math.abs(ageDate.getUTCFullYear() - 1970);
}

function beautify(options, personnels, callback) {
    var language = options.language || "";
    language = language.toLowerCase();
    var gt = dictionary.translator(language);
    if (options.beautify && options.beautify === true) {
        //Address
        personnels = controllers.configuration.beautifyAddress({language: language}, personnels);
        function LoopA(a) {
            if (a < personnels.length && personnels[a]) {
                controllers.positions.findPositionHelderBystaffId({req: options.req}, personnels[a]._id, function (err, affectation) {
                    if (err) {
                        log.error(err);
                        callback(err);
                    } else {

                        var status = (personnels[a].status) ? personnels[a].status : "";
                        var grade = (personnels[a].grade) ? personnels[a].grade : "";
                        var category = (personnels[a].category) ? personnels[a].category : "";

                        var highestLevelEducation = (personnels[a].qualifications) ? personnels[a].qualifications.highestLevelEducation : "";
                        var natureActe = (personnels[a].history) ? personnels[a].history.nature : "";
                        var corps = personnels[a].corps;

                        personnels[a].age = _calculateAge(new Date(personnels[a].birthDate));

                        var retirementLimit = 60;
                        //Decree N°2020/802 of 30 December 2020 of the President of the Republic harmonising the retirement age of civil servants.
                        if (personnels[a].status == "1") {//Civil servant
                            if (personnels[a].category && personnels[a].category != null && personnels[a].category != "") {
                                if ((personnels[a].category == "5" || personnels[a].category == "6")) { //for category 'C' and 'D' staff, retirement at 55
                                    retirementLimit = 55;
                                } else {//Harmonised at sixty (60) years for category 'A' and 'B' staff
                                    retirementLimit = 60;
                                }
                            } else {//Harmonised at sixty (60) years in case of other categories
                                retirementLimit = 60;
                            }
                        } else {// Contractual
                            if (personnels[a].category && personnels[a].category != null && personnels[a].category != "") {
                                if (parseInt(personnels[a].category, 10) >= 1 && parseInt(personnels[a].category, 10) <= 7) { //Personnel non fonctionnaire CAT 1 à CAT 7 at 55 ans
                                    retirementLimit = 55;
                                } else {//Personnel non fonctionnaire CAT 8 à CAT 12 à 60 ans
                                    retirementLimit = 60;
                                }
                            } else {//other in case
                                retirementLimit = 60;
                            }
                        }
                        personnels[a].retirementDate = new Date(personnels[a].birthDate).setFullYear(new Date(personnels[a].birthDate).getFullYear() + retirementLimit);



                        personnels[a].status = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status.json', status, language);

                        if (status != "") {
                            personnels[a].grade = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status/' + status + '/grades.json', parseInt(grade, 10), language);
                            personnels[a].category = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status/' + status + '/categories.json', category, language);

                            var thisgrade = dictionary.getJSONById('../../resources/dictionary/personnel/status/' + status + '/grades.json', parseInt(grade, 10), language);
                            if (thisgrade) {
                                corps = ((personnels[a].corps) ? personnels[a].corps : thisgrade.corps);
                            }

                            if (corps && corps != "") {
                                personnels[a].corps = dictionary.getValueFromJSON('../../resources/dictionary/personnel/status/' + status + '/corps.json', corps + "", language);
                            }
                        }

                        if (highestLevelEducation != "") {
                            personnels[a].qualifications.highestLevelEducation = dictionary.getValueFromJSON('../../resources/dictionary/personnel/educationLevels.json', parseInt(highestLevelEducation, 10), language);
                        }

                        if (natureActe != "") {
                            personnels[a].history.nature = dictionary.getValueFromJSON('../../resources/dictionary/acts/natures.json', natureActe, language);
                        }


                        var situations = personnels[a].situations;
                        if (situations && situations.length > 0) {
                            situations.sort(function (a, b) {
                                return new Date(b.lastModified) - new Date(a.lastModified);
                            });
                            for (var i in situations) {
                                situations[i].value = dictionary.getValueFromJSON('../../resources/dictionary/personnel/situations.json', situations[i].situation, language);
                            }
                            personnels[a].situations = situations;
                        }

                        var sanctions = personnels[a].sanctions;
                        if (sanctions && sanctions.length > 0) {
                            sanctions.sort(function (a, b) {
                                if (a && b && a != null && b != null && a != "null" && b != "null") {
                                    return new Date(b.date) - new Date(a.date);
                                } else {
                                    return 1;
                                }

                            });
                            for (var i in sanctions) {
                                if (sanctions[i]) {
                                    sanctions[i].value = dictionary.getValueFromJSON('../../resources/dictionary/personnel/sanctions.json', sanctions[i].sanction, language);
                                }
                            }
                            personnels[a].sanctions = sanctions;
                        }

                        personnels[a].affectedTo = affectation;
                        if (personnels[a].affectedTo && personnels[a].affectedTo.rank) {
                            personnels[a].affectedTo.rank = dictionary.getValueFromJSON('../../resources/dictionary/personnel/ranks.json', personnels[a].affectedTo.rank, language);
                        }
                        personnels[a].skillsCorresponding = 0;
                        personnels[a].profilesCorresponding = 0;

                        //ASKED BY DGTCFM ONLY FOR TRESOR STAFF
                        //TODO: Ajouter le corps du mestier dans chaque poste. Example : Tresor
                        //Ainsi, il nous suffira de comparer le corps réel du personnel et le corps du metier (lié au poste)
                        if (corps == "2") {//Corps des Régies Financières Trésor
                            personnels[a].skillsCorresponding = 40;
                            personnels[a].profilesCorresponding = 40;
                        }

                        var userProfiles = personnels[a].profiles;
                        var userSkills = personnels[a].skills;

                        var requiredProfiles = [];
                        var requiredSkills = [];

                        if (options.eligibleTo && options.position) {//Case we compute the eligibility, take it from the concerned position
                            requiredProfiles = options.position.requiredProfiles;
                            requiredSkills = options.position.requiredSkills;
                        } else {
                            if (personnels[a].affectedTo && personnels[a].affectedTo.position) {//Normal case. We just compute corresponding percentages
                                requiredProfiles = personnels[a].affectedTo.position.requiredProfiles;
                                requiredSkills = personnels[a].affectedTo.position.requiredSkills;
                            }
                        }

                        if (requiredProfiles && requiredProfiles.length > 0) {
                            var count = 0;
                            if (userProfiles && userProfiles.length > 0) {
                                for (var i in userProfiles) {
                                    if (requiredProfiles.includes(userProfiles[i])) {
                                        count = count + 1;
                                    }
                                }
                            }
                            personnels[a].profilesCorresponding += Number((100 * (count / requiredProfiles.length)).toFixed(1));
                            if (personnels[a].profilesCorresponding > 100) {
                                personnels[a].profilesCorresponding = 100;
                            }
                        }

                        if (requiredSkills && requiredSkills.length > 0) {
                            var count = 0;
                            if (userSkills && userSkills.length > 0) {
                                for (var i in userSkills) {
                                    if (requiredSkills.includes(userSkills[i])) {
                                        count = count + 1;
                                    }
                                }
                            }
                            personnels[a].skillsCorresponding += Number((100 * (count / requiredProfiles.length)).toFixed(1));
                            if (personnels[a].skillsCorresponding > 100) {
                                personnels[a].skillsCorresponding = 100;
                            }
                        }

                        personnels[a].corresponding = Number(((personnels[a].skillsCorresponding + personnels[a].profilesCorresponding) / 2).toFixed(1));



                        LoopA(a + 1);
                    }
                });
            } else {
                callback(null, personnels);
            }
        }

        LoopA(0);
    } else {
        callback(null, personnels);
    }
}

function buildXLSX(options, callback) {
    var add = 0;
    var defaultCellStyle = {font: {name: "Calibri", sz: 11}, fill: {fgColor: {rgb: "FFFFAA00"}}};
    var alpha = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
    var columns = [];
    var a = 0;
    // Generate fields

    for (n = 0; n < options.fields.length; n++) {
        if (n <= alpha.length * 1 - 1) {
            columns.push(alpha[a]);
        } else if (n <= alpha.length * 2 - 1) {
            columns.push(alpha[0] + alpha[a]);
        } else if (n <= alpha.length * 3 - 1) {
            columns.push(alpha[1] + alpha[a]);
        } else if (n <= alpha.length * 4 - 1) {
            columns.push(alpha[2] + alpha[a]);
        } else if (n <= alpha.length * 5 - 1) {
            columns.push(alpha[3] + alpha[a]);
        } else {
            columns.push(alpha[4] + alpha[a]);
        }
        a++;
        if (a > 25) {
            a = 0;
        }
    }

    // create workbook & add worksheet
    var workbook = new Excel.Workbook();
    //2. Start holding the work sheet
    var ws = workbook.addWorksheet('Admineex export');

    //3. set style around A1
    ws.getCell('A1').value = options.title;
    ws.getCell('A1').border = {
        top: {style: 'thick', color: {argb: 'FF964714'}},
        left: {style: 'thick', color: {argb: 'FF964714'}},
        bottom: {style: 'thick', color: {argb: 'FF964714'}}
    };
    ws.getCell('A1').fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFE06B21'}};
    ws.getCell('A1').font = {
        color: {argb: 'FFFFFF'},
        size: 16,
        bold: true
    };
    ws.getCell('A1').alignment = {vertical: 'middle', horizontal: 'center'};


    //4. Row 1
    for (i = 1; i < options.fieldNames.length; i++) {
        // For the last column, add right border
        if (i == options.fieldNames.length - 1) {
            ws.getCell(columns[i] + "1").border = {
                top: {style: 'thick', color: {argb: 'FF964714'}},
                right: {style: 'medium', color: {argb: 'FF964714'}},
                bottom: {style: 'thick', color: {argb: 'FF964714'}}
            };
        } else {//Set this border for the middle cells
            ws.getCell(columns[i] + "1").border = {
                top: {style: 'thick', color: {argb: 'FF964714'}},
                bottom: {style: 'thick', color: {argb: 'FF964714'}}
            };
        }
        ws.getCell(columns[i] + "1").fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFE06B21'}};
        ws.getCell(columns[i] + "1").alignment = {vertical: 'middle', horizontal: 'center', "wrapText": true};
    }

    //5 Row 2
    for (i = 0; i < options.fieldNames.length; i++) {
        ws.getCell(columns[i] + "2").value = options.fieldNames[i];
        ws.getCell(columns[i] + "2").alignment = {vertical: 'middle', horizontal: 'left', "wrapText": true};
        ws.getCell(columns[i] + "2").border = {
            top: {style: 'thin', color: {argb: 'FF000000'}},
            bottom: {style: 'medium', color: {argb: 'FF000000'}},
            left: {style: 'thin', color: {argb: 'FF000000'}},
            right: {style: 'thin', color: {argb: 'FF000000'}}
        };
    }

    //6. Fill data rows    
    var nextRow = 3;
    for (i = 0; i < options.data.length; i++) {
        if ((options.staffOnly != false && options.staffOnly != "false")) {
            //6.1 Row 3 set the style
            ws.getCell('A' + nextRow).value = options.data[i].name + " - " + options.data[i].code;
            ws.getCell('A' + nextRow).border = {
                top: {style: 'thick', color: {argb: 'FF964714'}},
                left: {style: 'thick', color: {argb: 'FF964714'}},
                bottom: {style: 'thick', color: {argb: 'FF964714'}}
            };
            ws.getCell('A' + nextRow).fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFE06B21'}};
            ws.getCell('A' + nextRow).font = {
                color: {argb: 'FFFFFF'},
                size: 16,
                bold: true
            };
            ws.getCell('A' + nextRow).alignment = {vertical: 'middle', horizontal: 'center'};
            //6.2 Row 3 set the length
            for (r = 1; r < options.fieldNames.length; r++) {
                // For the last column, add right border
                if (r == options.fieldNames.length - 1) {
                    ws.getCell(columns[r] + nextRow).border = {
                        top: {style: 'thick', color: {argb: 'FF964714'}},
                        right: {style: 'medium', color: {argb: 'FF964714'}},
                        bottom: {style: 'thick', color: {argb: 'FF964714'}}
                    };
                } else {//Set this border for the middle cells
                    ws.getCell(columns[r] + nextRow).border = {
                        top: {style: 'thick', color: {argb: 'FF964714'}},
                        bottom: {style: 'thick', color: {argb: 'FF964714'}}
                    };
                }
                ws.getCell(columns[r] + nextRow).fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFE06B21'}};
                ws.getCell(columns[r] + nextRow).alignment = {vertical: 'middle', horizontal: 'center', "wrapText": true};
            }
            /// 6.3 Merges Structure name cells
            ws.mergeCells('A' + nextRow + ":" + columns[options.fieldNames.length - 1] + nextRow);
        } else {
            nextRow = 4;
            nextRow = nextRow - 1;
        }

        if (options.data[i].children) {
            if ((options.staffOnly != false && options.staffOnly != "false")) {
                nextRow = nextRow + 1;
            }

            /// 6.4 fill data
            for (c = 0; c < options.data[i].children.length; c++) {

                if ((options.staffOnly !== false && options.staffOnly !== "false")) {
                    //6.4.1 Row 3 set the style
                    ws.getCell('A' + nextRow).value = options.data[i].children[c].fr + " - " + options.data[i].children[c].code;
                    ws.getCell('A' + nextRow).border = {
                        top: {style: 'thick', color: {argb: '96969696'}},
                        left: {style: 'thick', color: {argb: '96969696'}},
                        bottom: {style: 'thick', color: {argb: '96969696'}}
                    };
                    ws.getCell('A' + nextRow).fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'A1a8a1a1'}};
                    ws.getCell('A' + nextRow).font = {
                        color: {argb: 'FFFFFF'},
                        size: 16,
                        bold: true
                    };
                    ws.getCell('A' + nextRow).alignment = {vertical: 'middle', horizontal: 'center'};
                    //6.4.2 Row 3 set the length
                    for (r = 1; r < options.fieldNames.length; r++) {
                        // For the last column, add right border
                        if (r == options.fieldNames.length - 1) {
                            ws.getCell(columns[r] + nextRow).border = {
                                top: {style: 'thick', color: {argb: '96969696'}},
                                right: {style: 'medium', color: {argb: '96969696'}},
                                bottom: {style: 'thick', color: {argb: '96969696'}}
                            };
                        } else {//Set this border for the middle cells
                            ws.getCell(columns[r] + nextRow).border = {
                                top: {style: 'thick', color: {argb: '96969696'}},
                                bottom: {style: 'thick', color: {argb: '96969696'}}
                            };
                        }
                        ws.getCell(columns[r] + nextRow).fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'A1a8a1a1'}};
                        ws.getCell(columns[r] + nextRow).alignment = {vertical: 'middle', horizontal: 'left', "wrapText": true};
                    }
                    /// 6.4.3 Merges Structure name cells
                    ws.mergeCells('A' + nextRow + ":" + columns[options.fieldNames.length - 1] + nextRow);
                } else {
                    nextRow = nextRow - 1;
                }

                if (options.data[i].children[c].personnels) {


                    for (k = 0; k < options.data[i].children[c].personnels.length; k++) {

                        for (j = 0; j < options.fields.length; j++) {
                            var query = options.fields[j].split(".");
                            var value, field;

                            if (query.length == 1) {
                                value = options.data[i].children[c].personnels[k][query[0]] || "";
                                field = query[0];
                            } else if (query.length == 2) {
                                if (options.data[i].children[c].personnels[k][query[0]]) {
                                    value = options.data[i].children[c].personnels[k][query[0]][query[1]] || "";
                                } else {
                                    value = "";
                                }
                                field = query[1];
                            } else if (query.length == 3) {
                                if (options.data[i].children[c].personnels[k][query[0]] && options.data[i].children[c].personnels[k][query[0]][query[1]]) {
                                    value = options.data[i].children[c].personnels[k][query[0]][query[1]][query[2]] || "";
                                } else {
                                    value = "";
                                }
                                field = query[2];
                            } else if (query.length == 4) {
                                if (options.data[i].children[c].personnels[k][query[0]] && options.data[i].children[c].personnels[k][query[0]][query[1]] && options.data[i].children[c].personnels[k][query[0]][query[1]][query[2]]) {
                                    value = options.data[i].children[c].personnels[k][query[0]][query[1]][query[2]][query[3]] || "";
                                } else {
                                    value = "";
                                }
                                field = query[2];
                            }

                            if ((field == "testDate" || field == "requestDate" || field == "birthDate" || field == "signatureDate" || field == "positiveResultDate" || field == "startdate" || field == "cartridgeExpiryDate") && value != undefined && value != "" && value != null && value != "null") {
                                value = moment(value).format("DD/MM/YYYY");
                            }

                            ws.getCell(columns[j] + (nextRow + 1 + add)).value = (value != undefined && value != null && value != "null") ? value : "";
                            ws.getCell(columns[j] + (nextRow + 1 + add)).border = {
                                left: {style: 'thin', color: {argb: 'FF000000'}},
                                right: {style: 'thin', color: {argb: 'FF000000'}}
                            };

                            // Last row: Add border
                            if (i == options.data.length - 1) {
                                ws.getCell(columns[j] + (nextRow + 1 + add)).border.bottom = {style: 'thin', color: {argb: 'FF000000'}};
                            }
                        }
                        nextRow += 1;
                    }
                }
                nextRow += 1;
            }
            nextRow += 1;
        }
    }

    ///7. Set the columns width to 12
    for (k = 0; k < ws.columns.length; k++) {
        ws.columns[k].width = 30;
    }
    ws.columns[0].width = 50;
    ws.columns[1].width = 12;
    ws.columns[2].width = 12;
    ws.columns[3].width = 12;
    ws.columns[4].width = 30;
    ws.columns[5].width = 30;
    ws.columns[6].width = 30;
    ws.columns[14].width = 50;
    ws.columns[15].width = 30;
    ws.columns[15].width = 30;
    ws.columns[16].width = 50;
    ws.columns[19].width = 15;

    ///7. Merges cells
    ws.mergeCells('A1:' + columns[options.fieldNames.length - 1] + "1");


    // save workbook to disk
    var tmpFile = "./tmp/" + keyGenerator.generateKey() + ".xlsx";
    if (!fs.existsSync("./tmp")) {
        fs.mkdirSync("./tmp");
    }
    workbook.xlsx.writeFile(tmpFile).then(function () {
        callback(null, tmpFile);
    });
}

function buildXLSX2(options, callback) {
    var add = 0;
    var defaultCellStyle = {font: {name: "Calibri", sz: 11}, fill: {fgColor: {rgb: "FFFFAA00"}}};
    var alpha = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
    var columns = [];
    var a = 0;
    // Generate fields

    for (n = 0; n < options.fields.length; n++) {
        if (n <= alpha.length * 1 - 1) {
            columns.push(alpha[a]);
        } else if (n <= alpha.length * 2 - 1) {
            columns.push(alpha[0] + alpha[a]);
        } else if (n <= alpha.length * 3 - 1) {
            columns.push(alpha[1] + alpha[a]);
        } else if (n <= alpha.length * 4 - 1) {
            columns.push(alpha[2] + alpha[a]);
        } else if (n <= alpha.length * 5 - 1) {
            columns.push(alpha[3] + alpha[a]);
        } else {
            columns.push(alpha[4] + alpha[a]);
        }
        a++;
        if (a > 25) {
            a = 0;
        }
    }

    // create workbook & add worksheet
    var workbook = new Excel.Workbook();
    //2. Start holding the work sheet
    var ws = workbook.addWorksheet('Datatocare report');

    //3. set style around A1
    ws.getCell('A1').value = options.title;
    ws.getCell('A1').border = {
        top: {style: 'thick', color: {argb: 'FF964714'}},
        left: {style: 'thick', color: {argb: 'FF964714'}},
        bottom: {style: 'thick', color: {argb: 'FF964714'}}
    };
    ws.getCell('A1').fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFE06B21'}};
    ws.getCell('A1').font = {
        color: {argb: 'FFFFFF'},
        size: 16,
        bold: true
    };
    ws.getCell('A1').alignment = {vertical: 'middle', horizontal: 'center'};


    //4. Row 1
    for (i = 1; i < options.fieldNames.length; i++) {
        // For the last column, add right border
        if (i == options.fieldNames.length - 1) {
            ws.getCell(columns[i] + "1").border = {
                top: {style: 'thick', color: {argb: 'FF964714'}},
                right: {style: 'medium', color: {argb: 'FF964714'}},
                bottom: {style: 'thick', color: {argb: 'FF964714'}}
            };
        } else {//Set this border for the middle cells
            ws.getCell(columns[i] + "1").border = {
                top: {style: 'thick', color: {argb: 'FF964714'}},
                bottom: {style: 'thick', color: {argb: 'FF964714'}}
            };
        }
        ws.getCell(columns[i] + "1").fill = {type: 'pattern', pattern: 'solid', fgColor: {argb: 'FFE06B21'}};
        ws.getCell(columns[i] + "1").alignment = {vertical: 'middle', horizontal: 'center', "wrapText": true};
    }

    //5 Row 2
    for (i = 0; i < options.fieldNames.length; i++) {
        ws.getCell(columns[i] + "2").value = options.fieldNames[i];
        ws.getCell(columns[i] + "2").alignment = {vertical: 'middle', horizontal: 'left', "wrapText": true};
        ws.getCell(columns[i] + "2").border = {
            top: {style: 'thin', color: {argb: 'FF000000'}},
            bottom: {style: 'medium', color: {argb: 'FF000000'}},
            left: {style: 'thin', color: {argb: 'FF000000'}},
            right: {style: 'thin', color: {argb: 'FF000000'}}
        };
    }

    //6. Fill data rows    
    for (i = 0; i < options.data.length; i++) {
        for (j = 0; j < options.fields.length; j++) {
            var query = options.fields[j].split(".");
            var value, field;
            if (query.length == 1) {
                value = options.data[i][query[0]] == undefined ? "" : options.data[i][query[0]];
                field = query[0];
            } else if (query.length == 2) {
                if (options.data[i][query[0]]) {
                    value = options.data[i][query[0]][query[1]] == undefined ? "" : options.data[i][query[0]][query[1]];
                } else {
                    value = "";
                }
                field = query[1];
            } else if (query.length == 3) {
                if (options.data[i][query[0]] && options.data[i][query[0]][query[1]]) {
                    value = options.data[i][query[0]][query[1]][query[2]] == undefined ? "" : options.data[i][query[0]][query[1]][query[2]];
                } else {
                    value = "";
                }
                field = query[2];
            }

            if ((field == "testDate" || field == "requestDate" || field == "birthDate" || field == "positiveResultDate" || field == "startdate" || field == "cartridgeExpiryDate" || field == "dateBeginningSymptom") && value != undefined && value != "" && value != null && value != "null") {
                value = moment(value).format("DD/MM/YYYY");
            }

            ws.getCell(columns[j] + (i + 3 + add)).value = (value != undefined && value != null && value != "null") ? value : "";
            ws.getCell(columns[j] + (i + 3 + add)).border = {
                left: {style: 'thin', color: {argb: 'FF000000'}},
                right: {style: 'thin', color: {argb: 'FF000000'}}
            };

            // Last row: Add border
            if (i == options.data.length - 1) {
                ws.getCell(columns[j] + (i + 3 + add)).border.bottom = {style: 'thin', color: {argb: 'FF000000'}};
            }
        }
    }

    ///7. Set the columns width to 12
    for (k = 0; k < ws.columns.length; k++) {
        ws.columns[k].width = 12;
    }

    ///7. Merges cells
    ws.mergeCells('A1:' + columns[options.fieldNames.length - 1] + "1");
    ws.columns[0].width = 50;
    ws.columns[1].width = 52;
    ws.columns[2].width = 12;
    ws.columns[3].width = 50;

    // save workbook to disk
    var tmpFile = "./tmp/" + keyGenerator.generateKey() + ".xlsx";
    if (!fs.existsSync("./tmp")) {
        fs.mkdirSync("./tmp");
    }
    workbook.xlsx.writeFile(tmpFile).then(function () {
        callback(null, tmpFile);
    });
}