angular.module('FilterbarDirective', []).directive('filterbar', ['gettextCatalog', '$ocLazyLoad', '$injector', '$rootScope', '$state', function (gettextCatalog, $ocLazyLoad, $injector, $rootScope, $state) {
        return {
            restrict: 'A',
            scope: {
                search: '=',
                select: '=',
                daterange: '=',
                province: '=',
                district: '=',
                labs: '=',
                path: '=',
                disableThemes: '=',
                showGlobalView: '='
            },
            templateUrl: 'templates/filterbar.html',
            link: function ($scope, $element, $attrs) {
                $ocLazyLoad.load('js/services/UIService.js').then(function () {
                    var UI = $injector.get('UI');
                    $ocLazyLoad.load('js/services/UserService.js').then(function () {
                        var User = $injector.get('User');
                        User.list().then(function (response) {
                            $scope.users = response.data;
                            $scope.rootscope = $rootScope;

                            $scope.$watch(function () {
                                return $rootScope.range.from.value;
                            }, function () {
                                $scope.from = $rootScope.range.from.value;
                            }, true);

                            $scope.$watch(function () {
                                return $rootScope.range.to.value;
                            }, function () {
                                $scope.to = $rootScope.range.to.value;
                            }, true);


                            $scope.from = $rootScope.range.from.value;
                            $scope.to = $rootScope.range.to.value;
                            
                            var watch = {};
                            watch.activation = $rootScope.$watch('globalView.activated', function (newValue, oldValue) {
                                if (newValue == false) {
                                    $rootScope.globalView.selectedUser = undefined
                                }
                            }, true);
                            $scope.$on('$destroy', function () {// in case of directive destroy, we destroy the watch
                                watch.activation();
                            });
                        });
                    });
                });
            }
        }
    }]);