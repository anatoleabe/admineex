angular.module('Procras1Directive', []).directive('procras1', function (gettextCatalog, $ocLazyLoad, $injector, $rootScope) {
    return {
        restrict: 'AE',
        scope: {
            task: '=',
            status: '='
        },
        replace: true,
        templateUrl: 'templates/statistics/procrastinate/directives/procras1.html',
        link: function ($scope, $element, $attrs, scope) {
            $scope.loadingChart = true;
            $ocLazyLoad.load('js/services/TaskService.js').then(function () {
                var Task = $injector.get('Task');
                $ocLazyLoad.load('js/services/ChartService.js').then(function () {
                    var Card = $injector.get('Chart');
                    $scope.loading = true;
                    $scope.loadingChart = false;
                    $scope.nbTasks = 36;
                    var CARD_NAME = "procras1_2_3_4";

                    
                });
            });
        }
    };
});
