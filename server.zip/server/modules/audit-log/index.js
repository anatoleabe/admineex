
module.exports = require('./lib/auditlog');